let devider = {
  type: "divider",
};

let base_modal = {
  type: "modal",
  title: {
    type: "plain_text",
    text: "My App",
    emoji: true,
  },
  submit: {
    type: "plain_text",
    text: "Submit",
    emoji: true,
  },
  close: {
    type: "plain_text",
    text: "Cancel",
    emoji: true,
  },
  blocks: [
    devider,
    {
      type: "section",
      text: {
        type: "mrkdwn",
        text: "<https://sample.jp|バグ #40197> : *サポートフィーの算出の修正*",
      },
    },
    {
      type: "actions",
      elements: [
        {
          type: "static_select",
          placeholder: {
            type: "plain_text",
            text: "Ticket Status",
            emoji: true,
          },
          options: [
            {
              text: {
                type: "plain_text",
                text: "新規",
                emoji: true,
              },
              value: "new",
            },
            {
              text: {
                type: "plain_text",
                text: "進行中",
                emoji: true,
              },
              value: "value-1",
            },
            {
              text: {
                type: "plain_text",
                text: "フィードバック",
                emoji: true,
              },
              value: "value-2",
            },
          ],
          action_id: "actionId-0",
        },
        {
          type: "static_select",
          placeholder: {
            type: "plain_text",
            text: "Activity Type",
            emoji: true,
          },
          options: [
            {
              text: {
                type: "plain_text",
                text: "開発",
                emoji: true,
              },
              value: "value-0",
            },
            {
              text: {
                type: "plain_text",
                text: "テスト",
                emoji: true,
              },
              value: "value-1",
            },
            {
              text: {
                type: "plain_text",
                text: "会議・検討",
                emoji: true,
              },
              value: "value-2",
            },
          ],
          action_id: "actionId-3",
        },
      ],
    },
    {
      type: "section",
      text: {
        type: "plain_text",
        text: "作業時間",
      },
      accessory: {
        type: "timepicker",
        initial_time: "01:30",
        placeholder: {
          type: "plain_text",
          text: "Select time",
          emoji: true,
        },
        action_id: "timepicker-action",
      },
    },
    {
      type: "input",
      element: {
        type: "plain_text_input",
        multiline: true,
        action_id: "plain_text_input-action",
        placeholder: {
          type: "plain_text",
          text: "コメント",
          emoji: true,
        },
      },
      label: {
        type: "plain_text",
        text: " ",
        emoji: true,
      },
    },
    {
      type: "section",
      text: {
        type: "mrkdwn",
        text: " ",
      },
      accessory: {
        type: "button",
        text: {
          type: "plain_text",
          text: "削除",
          emoji: true,
        },
        value: "click_me_123",
        action_id: "button-action",
      },
    },
    {
      type: "divider",
    },
    {
      type: "divider",
    },
    {
      dispatch_action: true,
      type: "input",
      element: {
        type: "plain_text_input",
        action_id: "plain_text_input-action",
      },
      hint: {
        type: "plain_text",
        text: "#47516 'チケット題名'   　　　　あ　",
      },
      label: {
        type: "plain_text",
        text: "Ticket No.",
        emoji: true,
      },
    },
    {
      type: "section",
      text: {
        type: "mrkdwn",
        text: " ",
      },
      accessory: {
        type: "button",
        text: {
          type: "plain_text",
          text: "追加",
          emoji: true,
        },
        value: "click_me_123",
        action_id: "button-action",
      },
    },
  ],
};

module.exports = base_modal;
