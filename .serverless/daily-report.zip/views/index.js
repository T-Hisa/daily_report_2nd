const base_modal = require('./base_modal')
module.exports = {
  base_modal,
}