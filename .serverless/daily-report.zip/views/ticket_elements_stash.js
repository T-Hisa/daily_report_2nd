const axios = require("axios");
let base_url = process.env.REDMINE_URL;

let build_options = (values) => {
  return values.map((v) => ({
    text: {
      type: "plain_text",
      text: v.name,
    },
    value: String(v.id),
  }));
};

let status_options = (statuses) => {
  if (statuses.length === 0) {
    try {
      let get_statuses_url = base_url + "/issue_statuses.json";
      axios.get(get_statuses_url).then((status_response) => {
        let issue_statuses = status_response["data"]["issue_statuses"];
        statuses = issue_statuses.map((status) => ({
          id: status.id,
          name: status.name,
        }));
        return build_options(statuses);
      });
    } catch (e) {
      console.error(e);
    }
  } else {
    return build_options(statuses);
  }
};

let status_element = (statuses) => ({
  type: "static_select",
  placeholder: {
    type: "plain_text",
    text: "Ticket Status",
  },
  options: status_options(statuses),
  action_id: "actionId-0",
});

let activity_options = (activities) => {
  if (activities.length === 0) {
    try {
      let get_activities_url =
        base_url + "/enumerations/time_entry_activities.json";
      axios.get(get_activities_url).then((activity_res) => {
        let time_activities = activity_res["data"]["time_entry_activities"];
        activities = time_activities.map((activity) => ({
          id: activity.id,
          name: activity.name,
        }));
        return build_options(activities);
      });
    } catch (e) {
      console.error(e);
    }
  } else {
    return build_options(activities);
  }
};

let activity_element = (activities) => ({
  type: "static_select",
  placeholder: {
    type: "plain_text",
    text: "Activity Type",
  },
  options: activity_options(activities),
  action_id: "actionId-3",
});

// ここで、axios を使用したステータス一覧の取得を行う
module.exports = { status_element, activity_element };
